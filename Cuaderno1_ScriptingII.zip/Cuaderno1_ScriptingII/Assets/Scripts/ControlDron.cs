﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlDron : MonoBehaviour {

    CharacterController cmpCC;

    Vector3 velocidadDeseada;
    Vector3 velocidadZ;
    Vector3 velocidadActual;

    public float aceleracion;
    public float speed;
    public float rotSpeed;
    public float alturaSpeed;

    public float distanciaChoqueTecho = 0.7f;
    float gravedad = -9.8f;

    public float DronSpeed;

    // Use this for initialization
    void Start ()
    {
        cmpCC = GetComponent<CharacterController>();
        velocidadActual = new Vector3(0, 0, 0);        
	}
	
	// Update is called once per frame
	void Update ()
    {
        Movimiento();
        choqueTecho();

        //Para coger la velocidad del dron en un float.
        Vector3 velocidadDron = cmpCC.velocity;
        velocidadDron = new Vector3(cmpCC.velocity.x, 0, cmpCC.velocity.z);
        DronSpeed = velocidadDron.magnitude;

    }
    private void Movimiento()
    {
        float yRotate = Input.GetAxis("Horizontal") * rotSpeed * Time.deltaTime; // Almacena en una variable la informacion de rotacion en el eje Y
        this.transform.Rotate(0, yRotate, 0); // con un Rotate se hace que se ejecute esa rotacion cuando se pulse el input mapeado en Horizontal

        float elevate = Input.GetAxis("Altura") * alturaSpeed; // Almacena en una variable la informacion de elevacion en el eje Y
        float zInput = Input.GetAxis("Vertical") * speed; // Almacena en una variable la informacion de movimiento en el eje Z
   
        Vector3 velocidadElevate = transform.up * elevate; // Se crea un Vector3 que almacena el movimiento de elevar para ejecutarlo en el eje Y Local con un transform.up
        Vector3 velocidadZ = transform.forward * zInput; // Se crea un Vector3 que almacena el movimiento horizontal para ejecutralo en el eje Z Local con un transform.forward

        velocidadDeseada = velocidadElevate + velocidadZ; // Se hace una suma de los dos vectores para almacenarlo en un solo vector
        velocidadActual = Vector3.MoveTowards(velocidadActual, velocidadDeseada, aceleracion * Time.deltaTime); //Se sobreescribe el vector de la velocidadActual con un MoveTowards para que el aumento de velocidad sea gradual
        cmpCC.Move(velocidadActual); // Se le aplica ese vector de movimiento al Chacarter Controller y listo.

    }

    private void choqueTecho()
    {
       if(cmpCC.collisionFlags == CollisionFlags.Above)
       {
            cmpCC.enabled = false;

            transform.Translate (Vector3.up * gravedad * Time.deltaTime);

            float tiempoRebote = 3;
            //float tiempo = 3;

            if (Time.time > tiempoRebote)
            {
                cmpCC.enabled = true;                  
            }

            if(cmpCC.collisionFlags == CollisionFlags.Below)
            {
                cmpCC.enabled = true;
            }
       }
    }

    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        //Para empujar a otro objeto dinámico.
        Rigidbody body = hit.collider.attachedRigidbody; //Almacena el rigidbody del objeto con el que colisiona.
        Vector3 direccionEmpuje = new Vector3(hit.moveDirection.x, 0, hit.moveDirection.z); //Almacena la dirección del dron cuando choca con el otro objeto.   
        body.velocity = direccionEmpuje * DronSpeed; //Se le da la velocidad que tenía el dron en el momento del impacto (x, 0, z) al objeto.

    }
}

