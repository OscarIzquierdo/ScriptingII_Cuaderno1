﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class ControlThirdPerson1 : MonoBehaviour {

    NavMeshAgent cmpNav;

	// Use this for initialization
	void Start ()
    {
        cmpNav = GetComponent<NavMeshAgent>();        
	}
	
	// Update is called once per frame
	void Update ()
    {
        GoToCursorClick();
		
	}

    void GoToCursorClick()
    {
        
        if (Input.GetMouseButton(0))
        {
            RaycastHit hit;
            Vector3 mousePos = Input.mousePosition;
            Ray ray = Camera.main.ScreenPointToRay(mousePos);
            if (Physics.Raycast(ray, out hit, Mathf.Infinity))
            {
                cmpNav.SetDestination(hit.point);
            }
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            cmpNav.ResetPath();
        }
        
    }
}
