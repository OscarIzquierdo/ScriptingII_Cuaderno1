﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class ControlThirdPerson2 : MonoBehaviour {

    NavMeshAgent cmpNav;

    Transform ball;

    bool verificar;

	// Use this for initialization
	void Start ()
    {
        cmpNav = GetComponent<NavMeshAgent>();
        ball = GetComponent<Transform>();
        
    }
	
	// Update is called once per frame
	void Update ()
    {        
        CalcularRuta();	
	}

    void CalcularRuta()
    {
        
        if (Input.GetMouseButton(0))
        {            
            
                RaycastHit hit;
                Vector3 mousePos = Input.mousePosition;
                Ray ray = Camera.main.ScreenPointToRay(mousePos);
                if (Physics.Raycast(ray, out hit, Mathf.Infinity))
                {
                    NavMeshPath path = new NavMeshPath();
                    cmpNav.CalculatePath(hit.point, path);
                    if (!(path.status == NavMeshPathStatus.PathPartial))
                    {
                        cmpNav.SetPath(path);
                        verificar = true;
                        print(verificar);
                    }
                    else
                    {
                        verificar = false;
                        print(verificar);
                    }
                }                       
        }
        if (Input.GetKeyDown(KeyCode.Space))
        {
            cmpNav.ResetPath();
        }
    }
}
