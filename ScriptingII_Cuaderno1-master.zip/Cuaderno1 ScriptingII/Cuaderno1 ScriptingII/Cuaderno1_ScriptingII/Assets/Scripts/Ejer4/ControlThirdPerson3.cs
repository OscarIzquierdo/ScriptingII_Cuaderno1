﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class ControlThirdPerson3 : MonoBehaviour {

    NavMeshAgent cmpNav;

	// Use this for initialization
	void Start ()
    {
        cmpNav = GetComponent<NavMeshAgent>();        
	}
	
	// Update is called once per frame
	void Update ()
    {
        Movimiento();
	}   

    void Movimiento()
    {
        if (Input.GetKey(KeyCode.W))
        {
            cmpNav.velocity = transform.forward * cmpNav.speed;
        }
        if (Input.GetKey(KeyCode.S))
        {
            cmpNav.velocity = -transform.forward * cmpNav.speed;
        }
        if (Input.GetKey(KeyCode.D))
        {
            cmpNav.velocity = transform.right * cmpNav.speed;
        }
        if (Input.GetKey(KeyCode.A))
        {
            cmpNav.velocity = -transform.right * cmpNav.speed;
        }
    }
}
